document.getElementById("textoInicial").textContent = "Para ingresar al CV de William Delos deberás ingresar la contraseña correcta.";
document.getElementById("chequear").addEventListener("click", function() {
    let contraseñaIngresada = document.getElementById("contraseña").value;
    verificarContraseña(contraseñaIngresada);
});

function verificarContraseña(contraseñaIngresada) {
    if (contraseñaIngresada == "Incorrecta") {
        IngresoCV();
        experienciaLaboral();
        JSONhabilidades();
        estudios();
        document.getElementById("textoIncorrecta").textContent = "";
    } else {
        document.getElementById("textoIncorrecta").textContent ="La contraseña es: Incorrecta";
    }
}

function IngresoCV(){
    document.getElementById("ingresoExitoso").textContent = "Bienvenido al CV del Lic. William delos";
    document.getElementById("fotoCV").style.display = "inline-block"
    document.getElementById("nombre").textContent = "Nombre: William Thomas Delos"
    document.getElementById("puesto").textContent = "Programador Jr"
    document.getElementById("mail").textContent = "MAIL: williamtdelos@gmail.com"
    document.getElementById("celular").textContent = "Telefono: +54 11 4405-8267"
    document.getElementById("direccion").textContent = "Direccion: Quesada 4464"
    document.getElementById("cumpleaños").textContent = "Fecha de Nacimiento: 02/02/2004"
    document.getElementById("edad").textContent = "EDAD: 22 años"
    document.getElementById("experiencia").textContent = "EXPERIENCIA LABORAL"
    document.getElementById("resumen").textContent = "Resumen:"
    document.getElementById("desc").textContent = "Programador junior con conocimientos en desarrollo web y resolución de problemas. Me destaco por el pensamiento lógico, la responsabilidad y el trabajo en equipo. Interesado en crear aplicaciones funcionales y seguir creciendo profesionalmente."
}

function experienciaLaboral(){
    document.getElementById("botonesExperiencia").style.display="flex"
    document.getElementById("verMas1").style.display="flex"
    document.getElementById("verMas2").style.display="flex"
    document.getElementById("cuadrados").style.display="flex"
    document.getElementById("verMas1").addEventListener("click", function(){
        const cubo = "cubo1"
        cambiarEXP(cubo)
    });
    document.getElementById("verMas2").addEventListener("click", function(){
        const cubo = "cubo2"
        cambiarEXP(cubo)
    });
}

function cambiarEXP(cubo){
    if(cubo == "cubo1") {
        document.getElementById(cubo).textContent = "Desarrollo independiente de aplicacion para dispositivos moviles: 'Splendid Tales' como proyecto universitario"
        document.getElementById(cubo).style.backgroundColor = "rgb(220, 255, 104)";
    } else if(cubo == "cubo2"){
        document.getElementById(cubo).textContent = "revision y correccion de codigo en la empresa P.A.L inc. debug y registro del progreso durante el desarrollo del algoritmo"
        document.getElementById(cubo).style.backgroundColor = "rgb(220, 255, 104)";
    }
    }


const habilidadesLaborales = {
    responsable: "Cumplo con tareas y plazos establecidos",
    puntual: "Respeto horarios y tiempos de entrega",
    pensamiento_Critico: "Analizo problemas y propongo soluciones"
};

const clavesHab = Object.keys(habilidadesLaborales);
let indiceHab = 0;
document.getElementById("mostrarHabilidades").addEventListener("click", function () {
    let clave = clavesHab[indiceHab];
    document.getElementById("tituloHabilidad").textContent = clave;
    document.getElementById("descripcion").textContent = habilidadesLaborales[clave];
    indiceHab++;
    if (indiceHab >= clavesHab.length) {
        indiceHab = 0;
    }
});
function JSONhabilidades(){
    document.getElementById("habilidades").textContent = "Perfil de habilidades:";
    document.getElementById("mostrarHabilidades").style.display = "flex";
    let clave = clavesHab[0];
    document.getElementById("tituloHabilidad").textContent = clave;
    document.getElementById("descripcion").textContent = habilidadesLaborales[clave];
    indiceHab = 1;
}

function estudios() {
    document.getElementById("estudios").textContent = "Estudios:";
    document.getElementById("estudio").style.display = "flex";
    document.getElementById("secundario").addEventListener("mouseover", function () {
        mostrar("secundario");
    });
    document.getElementById("universidad").addEventListener("mouseover", function () {
        mostrar("universidad");
    });
    document.getElementById("cursos").addEventListener("mouseover", function () {
        mostrar("cursos");
    });
}

function mostrar(seccion) {
    let elemento = document.getElementById(seccion);
    if (seccion === "secundario") {
        elemento.textContent = "Colegio San Francisco (2020-2024) orientación en informática";
    } 
    else if (seccion === "universidad") {
        elemento.textContent = "Universidad de Buenos Aires (2025-2031) Lic. Ciencias de la Computación";
    } 
    else {
        elemento.textContent = "Programación en JS y HTML (2025)";
    }
    elemento.style.backgroundColor = "rgb(220, 255, 104)";
    }
