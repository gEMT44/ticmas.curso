package com.example.comparadortextos

import androidx.test.espresso.Espresso.*
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.assertion.ViewAssertions.*
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.rules.ActivityScenarioRule
import org.junit.Rule
import org.junit.Test

class MainActivityTest {

    @get:Rule
    val activityRule = ActivityScenarioRule(MainActivity::class.java)

    @Test
    fun compararTextosIguales() {

        onView(withId(R.id.texto1)).perform(typeText("hola"))
        onView(withId(R.id.texto2)).perform(typeText("hola"))

        closeSoftKeyboard()

        onView(withId(R.id.botonComparar)).perform(click())

        onView(withId(R.id.resultado))
            .check(matches(withText("Los textos son iguales")))

    }
}