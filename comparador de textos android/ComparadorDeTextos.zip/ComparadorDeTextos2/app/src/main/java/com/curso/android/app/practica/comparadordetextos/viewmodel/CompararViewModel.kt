package com.example.comparadortextos.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.comparadortextos.repository.CompararRepository

class CompararViewModel : ViewModel() {

    private val repository = CompararRepository()

    private val _resultado = MutableLiveData<String>()
    val resultado: LiveData<String> = _resultado

    fun comparar(texto1: String, texto2: String) {

        if(repository.comparar(texto1, texto2)){
            _resultado.value = "Los textos son iguales"
        }else{
            _resultado.value = "Los textos son diferentes"
        }

    }
}