package com.example.comparadortextos.repository

class RepositorioComparar {

    fun comparar(texto1: String, texto2: String): Boolean {
        return texto1 == texto2
    }

}