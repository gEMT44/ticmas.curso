package com.example.comparadortextos

import com.example.comparadortextos.repository.CompararRepository
import org.junit.Assert.assertTrue
import org.junit.Test

class CompararRepositoryTest {

    private val repository = CompararRepository()

    @Test
    fun textosIguales_devuelveTrue(){

        val resultado = repository.comparar("hola","hola")

        assertTrue(resultado)
    }
}