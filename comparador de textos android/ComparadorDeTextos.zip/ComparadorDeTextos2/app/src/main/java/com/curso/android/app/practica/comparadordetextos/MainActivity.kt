package com.example.comparadortextos

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import com.example.comparadortextos.databinding.ActivityMainBinding
import com.example.comparadortextos.viewmodel.CompararViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: CompararViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.botonComparar.setOnClickListener {

            val texto1 = binding.texto1.text.toString()
            val texto2 = binding.texto2.text.toString()

            viewModel.comparar(texto1, texto2)
        }

        viewModel.resultado.observe(this) {

            binding.resultado.text = it

        }

    }
}